#include "board.hpp"
#include "tables.hpp"
#include <string.h>
#include <stdio.h>

// the readability is sacrificed for the performance
// If you facing any problem, just contact TA
void Board::init_with_piecepos(int input_piecepos[2][6], char input_color)
{
    color = input_color;
    memcpy(piece_pos, input_piecepos, 12 * sizeof(int));
    memset(board, -1, 25 * sizeof(int));
    piece_bits[RED] = 0;
    piece_bits[BLUE] = 0;
    for (int _color = 0; _color < 2; _color++)
    {
        for (int _piece = 0; _piece < 6; _piece++)
        {
            int pos = input_piecepos[_color][_piece];
            if (pos >= 0)
            {
                board[pos] = _piece + 6 * _color;
                piece_bits[_color] += bit_mask(_piece);
            }
        }
    }
}
void Board::move(int id_with_dice)
{
    int id = id_with_dice / PIECE_NUM;
    dice = id_with_dice % PIECE_NUM;
    int start = moves[id][0], end = moves[id][1];
    int piece = board[start], end_piece = board[end];
    board[start] = -1;
    if (end_piece >= 0)
    {
        if (end_piece < PIECE_NUM)
        {
            piece_bits[RED] &= ~bit_mask(end_piece);
            piece_pos[RED][end_piece] = -1;
        }
        else
        {
            piece_bits[BLUE] &= ~bit_mask(end_piece - PIECE_NUM);
            piece_pos[BLUE][end_piece - PIECE_NUM] = -1;
        }
    }
    piece_pos[color][piece % PIECE_NUM] = end;
    board[end] = piece;
    color ^= 1;
}
void Board::generate_moves()
{
    int movable_piece1, movable_piece2;
    int *result1, *result2;
    int pos1, pos2;
    movable_piece1 = dice2num[piece_bits[color]][dice][0];
    if (movable_piece1 == -1)
    {
        // this should not happen...
        return;
    }
    movable_piece2 = dice2num[piece_bits[color]][dice][1];
    if (movable_piece2 == -1)
    {
        pos1 = piece_pos[color][movable_piece1];
        pos2 == -1;
        result1 = (int *)pos2steps[color][pos1];
        move_count = result1[3];
    }
    else
    {
        pos1 = piece_pos[color][movable_piece1];
        pos2 = piece_pos[color][movable_piece2];
        result1 = (int *)pos2steps[color][pos1];
        result2 = (int *)pos2steps[color][pos2];
        move_count = result1[3] + result2[3];
    }
    // gen moves
    int i = 0;
    for (; i < result1[3]; i++)
    {
        moves[i][0] = pos1;
        moves[i][1] = result1[i];
    }
    for (; i < move_count; i++)
    {
        moves[i][0] = pos2;
        moves[i][1] = result2[i - result1[3]];
    }
    move_count *= PIECE_NUM;
    return;
}
bool Board::check_winner()
{
    if (color == RED)
    {
        if (piece_bits[RED] == 0 || (board[0] >= PIECE_NUM))
            return true;
        return false;
    }
    // blue
    else
    {
        if (piece_bits[BLUE] == 0 || (0 <= board[24] && board[24] < PIECE_NUM))
            return true;
        return false;
    }
}
void Board::print_board()
{
    for (int y = 0; y < 5; y++)
    {
        for (int x = 0; x < 5; x++)
        {
            if (board[5 * y + x] == -1)
            {
                printf("_ ");
            }
            else if (board[5 * y + x] < PIECE_NUM)
            {
                printf("%c ", 'A' + board[5 * y + x]);
            }
            else
            {
                printf("%d ", board[5 * y + x] - PIECE_NUM + 1);
            }
        }
        printf("\n");
    }
    printf("dice: %d\n", dice + 1);
    printf("================\n");
}
