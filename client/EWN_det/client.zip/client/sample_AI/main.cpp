#include <stdio.h>
#include <time.h>
#include <array>
#include <random>
#include <algorithm>
#include <string.h>
#include "board/board.hpp"

int main()
{
    // Disable buffering on stdout, making it unbuffered
    setvbuf(stdout, NULL, _IONBF, 0);
    // Disable buffering on stderr, making it unbuffered
    setvbuf(stderr, NULL, _IONBF, 0);

#define COMMAND_UPDATE 0
#define COMMAND_EXIT 1

    while (true)
    {
        double timer;
        int command, color, dice;
        int piece_position[2][6];
        scanf("%d", &command);
        switch (command)
        {
        case COMMAND_UPDATE:
        {
            scanf("%d", &color);
            scanf("%lf", &timer);
            for (int _color_ = 0; _color_ < 2; _color_++)
            {
                for (int piece_num = 0; piece_num < 6; piece_num++)
                {
                    scanf("%d", &piece_position[_color_][piece_num]);
                }
            }
            scanf("%d", &dice);
            Board current_board;
            current_board.init_with_piecepos(piece_position, color);
            current_board.dice = dice;
            current_board.print_board();
            int step;
            if (dice == -1)
            {
                step = current_board.first_move_decide_dice();
                // reply steps
                fprintf(stderr, "====>%d %d %d\n", step, 0, 0);
            }
            else
            {
                current_board.generate_moves();
                step = current_board.decide();
                int step_id = step / PIECE_NUM;
                int step_dice = step % PIECE_NUM;
                int step_start = current_board.moves[step_id][0], step_destination = current_board.moves[step_id][1];
                // reply steps
                fprintf(stderr, "====>%d %d %d\n", step_dice, current_board.board[step_start] - color * PIECE_NUM, step_destination);
            }
            break;
        }
        case COMMAND_EXIT:
        {
            printf("exit normally...");
            // you can add your exit handler here
            return 0;
            break;
        }
        default:
            break;
        }
    }
    return 0;
}